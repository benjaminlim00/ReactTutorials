const express = require("express");
const app = express();

app.get("/", (req, res) => {
  res.send("hello world");
});

app.get("/example", (req, res) => {
  res.send("hello world from example");
});

app.get("/example/:name/:age", (req, res) => {
  console.log(req.params); //we add by adding /
  console.log(req.query); //we can add by using ? and & for multiple query
  res.send(req.params.name + " is " + req.params.age + " years old");
});

app.listen(3000);
