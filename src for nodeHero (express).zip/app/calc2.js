const calc = require("./calc");

const numbersToAdd = [3, 4, 10, 2];

const result = calc.sum(numbersToAdd);
console.log(`the result is: ${result}`);
