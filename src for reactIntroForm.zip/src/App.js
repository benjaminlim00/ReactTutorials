import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import Greetings from "./components/Greetings";
import SimpleForm from "./components/SimpleForm";

const App = () => (
  <div>
    <SimpleForm />
  </div>
);

export default App;
