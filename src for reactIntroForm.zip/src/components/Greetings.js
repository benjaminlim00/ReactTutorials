import React from "react";

const Greetings = ({ firstName, lastName }) => (
  <div>
    Hey you! {firstName} {lastName}
  </div>
);
export default Greetings;
