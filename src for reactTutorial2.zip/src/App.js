import React from "react";
import logo from "./logo.svg";
import "./App.css";

import Header from "./components/Header";
import Ben from "./components/Ben";
import Kittens from "./components/Kittens";
import TodoItem from "./components/TodoItem";
import Joke from "./components/Joke";
import JokeList from "./components/JokeList";
import ProductList from "./components/ProductList";
import StateTest from "./components/StateTest";
import Login from "./components/Login";
import EventTest from "./components/EventTest";
import TodoData from "./components/TodoData";
import StateButton from "./components/StateButton";
import ConTest from "./components/ConTest";
import ButtonLogin from "./components/ButtonLogin";
import ApiData from "./components/ApiData";
import Forms from "./components/Forms";
import FormsContainer from "./components/FormsContainer";

class App extends React.Component {
  render() {
    return (
      <div>
        <FormsContainer />
      </div>
    );
  }
}

export default App;
