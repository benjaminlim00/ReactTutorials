import React from "react";

class Login extends React.Component {
  constructor() {
    super();
    this.state = {
      isLoggedIn: true
    };
  }
  render() {
    let word;
    if (this.state.isLoggedIn) {
      word = "in";
    } else {
      word = "out";
    }
    return <div>You are currently logged {word}</div>;
  }
}

export default Login;
