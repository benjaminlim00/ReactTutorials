const TodoData = [
  {
    id: 1,
    text: "clean room",
    completed: false
  },
  {
    id: 2,
    text: "clear trash",
    completed: false
  },
  {
    id: 3,
    text: "clean house",
    completed: false
  },
  {
    id: 4,
    text: "eat",
    completed: true
  }
];

export default TodoData;
