import React from "react";

const firstname = "benjamin";
const lastname = "lim";

const Header = () => (
  <div>
    <header className="navbar">Hi, i am Header</header>

    <h1>Hello {`${firstname} ${lastname}`}</h1>
    {/*use {} to do anything related to js could have done
    {firstname + " " + lastname}
    */}
  </div>
);

export default Header;
