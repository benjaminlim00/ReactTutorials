import React from "react";

function Ben() {
  const styles = { color: "#FF8C00", backgroundColor: "#FF2D00" };

  return (
    <div>
      <h3 style={styles}>im ben</h3>
    </div>
  );
}

export default Ben;
