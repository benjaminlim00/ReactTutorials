import React from "react";
import Joke from "./Joke";

class JokeList extends React.Component {
  render() {
    return (
      <div>
        <Joke punchline="i walked into a bar..." />
        <Joke
          question="What's the best thing about Switzerland"
          punchline="i don't know, but the flag is a big plus"
        />
      </div>
    );
  }
}
export default JokeList;
