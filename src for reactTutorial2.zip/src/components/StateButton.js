import React from "react";

class StateButton extends React.Component {
  constructor() {
    super();
    this.state = {
      count: 1
    };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick = () =>
    this.setState(prevState => {
      //we can name prevState as anything
      return {
        count: prevState.count * 2
      };
    });

  render() {
    return (
      <div>
        <h1>{this.state.count}</h1>
        <button onClick={this.handleClick}>Click to times two!</button>
      </div>
    );
  }
}

export default StateButton;
