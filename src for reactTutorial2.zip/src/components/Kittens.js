import React from "react";
import ContactCard from "./ContactCard";

function Kittens() {
  return (
    <div>
      <ContactCard
        contact={{
          name: "Mr Whisker",
          imgUrl: "http://placekitten.com/300/200",
          phone: "12321312",
          email: "mrwhisker.gmail.com"
        }}
      />
      <ContactCard
        contact={{
          name: "johnny walker",
          imgUrl: "http://placekitten.com/400/200",
          phone: "1232",
          email: "johhnywalker.gmail.com"
        }}
      />
      <ContactCard
        contact={{
          name: "Destroyer",
          imgUrl: "http://placekitten.com/400/100",
          phone: "1232131123122",
          email: "Destroyer.gmail.com"
        }}
      />
      <ContactCard
        contact={{
          name: "Mrmr",
          imgUrl: "http://placekitten.com/400/300",
          phone: "12321312",
          email: "mrmr.gmail.com"
        }}
      />
    </div>
  );
}

export default Kittens;
