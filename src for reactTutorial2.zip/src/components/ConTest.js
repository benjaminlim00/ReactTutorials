import React from "react";
import Conditional from "./Conditional";

class ConTest extends React.Component {
  constructor() {
    super();
    this.state = {
      isLoading: true
    };
  }

  componentDidMount() {
    setTimeout(() => {
      this.setState({
        isLoading: false
      });
    }, 1500);
  }

  render() {
    return <Conditional isLoading={this.state.isLoading} />;
  }
}
export default ConTest;

//must put the contents of this file into app to run
