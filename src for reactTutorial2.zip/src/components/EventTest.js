import React from "react";

class EventTest extends React.Component {
  render() {
    function handleClick() {
      console.log("i was clicked");
    }

    return (
      <div>
        <img
          src="https://images.pexels.com/photos/104827/cat-pet-animal-domestic-104827.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260"
          alt="cat pic"
          onMouseOver={() => console.log("Hovered!")}
        />
        <br />
        <br />
        <button onClick={handleClick}>Click me</button>
      </div>
    );
  }
}

export default EventTest;
