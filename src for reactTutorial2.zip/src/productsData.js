const products = [
  { id: "1", name: "Pencil", price: 1, description: "use to write" },
  {
    id: "2",
    name: "Pen",
    price: 3,
    description: "use to write but cannot erase"
  },
  { id: "3", name: "Coffee", price: 5, description: "yummy" },
  { id: "4", name: "House", price: 10000, description: "live in it" },
  { id: "5", name: "Ball", price: 40, description: "Bounce " },
  { id: "6", name: "Hat", price: 20, description: "use to write" }
];
export default products;
