import React from "react";
import "../App.css";

const NotFound = () => (
  <div className="jumbotron">
    <h1>Not Found</h1>
  </div>
);

export default NotFound;
