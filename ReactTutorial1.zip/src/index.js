import React from "react";
import ReactDOM from "react-dom";
import Form from "./components/Form";
import Counter from "./components/Counter";
import "./styles.css";

function MessageTwo({ message }) {
  return (
    <div>{message ? <div>{message}</div> : <div>No Message from two</div>}</div>
  );
}
const content = "benjamin";
const Message = props => <h3>Hello {props.msg}</h3>;
const App = () => (
  <div className="Title">
    <MessageTwo message="ef" />
    Hello {content}, nice to meet you
    <Message msg="jon" />
    <Counter />
    <Form
      getErrorMessage={value => {
        if (value.length < 3) {
          return `value must be at least 3 chars`;
        } else {
          return null;
        }
      }}
    />
  </div>
);

ReactDOM.render(<App />, document.getElementById("root"));
