import React from "react";
import ReactDOM from "react-dom";

class NameForm extends React.Component {
  state = { error: this.props.getErrorMessage("") };
  handleSubmit = event => {
    event.preventDefault();
    const value = this.inputNode.value; //event.target.elements.username.value

    const error = this.props.getErrorMessage(value);
    if (error) {
      alert(`error: ${error}`);
    } else {
      alert(`you entered ${value}`);
    }
  };

  handleChange = event => {
    const { value } = event.target;
    this.setState({
      error: this.props.getErrorMessage(value)
    });
  };

  render() {
    const { error } = this.state;
    return (
      <form onSubmit={this.handleSubmit}>
        <label>
          Name:
          <input
            type="text"
            onChange={this.handleChange}
            name="username"
            ref={node => (this.inputNode = node)}
          />
        </label>
        {error ? <div style={{ color: "red" }}>{error}</div> : null}
        <button disabled={Boolean(error)} type="submit">
          Submit
        </button>
      </form>
    );
  }
}

export default NameForm;
